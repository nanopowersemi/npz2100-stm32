Core/Src/npz2100_all.o: ../Core/Src/npz2100_all.c \
 ../Core/Src/../../NPZ2100/Src/npz2100.c ../NPZ2100/Inc/npz2100_hal.h \
 ../Core/Src/../../NPZ2100/Src/npz2100_mid.c ../NPZ2100/Inc/npz2100_mid.h \
 ../NPZ2100/Inc/npz2100_hal.h ../NPZ2100/Inc/npz2100_regs_system.h \
 ../NPZ2100/Inc/npz2100_regs_io.h ../NPZ2100/Inc/npz2100_regs_periph.h \
 ../NPZ2100/Inc/npz2100_regs_adc_log.h \
 ../Core/Src/../../NPZ2100/Src/npz2100_stm32.c \
 ../NPZ2100/Inc/npz2100_stm32.h \
 ../Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal.h \
 ../Core/Inc/stm32l0xx_hal_conf.h \
 ../Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_rcc.h \
 ../Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_def.h \
 ../Drivers/CMSIS/Device/ST/STM32L0xx/Include/stm32l0xx.h \
 ../Drivers/CMSIS/Device/ST/STM32L0xx/Include/stm32l053xx.h \
 ../Drivers/CMSIS/Include/core_cm0plus.h \
 ../Drivers/CMSIS/Include/cmsis_version.h \
 ../Drivers/CMSIS/Include/cmsis_compiler.h \
 ../Drivers/CMSIS/Include/cmsis_gcc.h \
 ../Drivers/CMSIS/Include/mpu_armv7.h \
 ../Drivers/CMSIS/Device/ST/STM32L0xx/Include/system_stm32l0xx.h \
 ../Drivers/STM32L0xx_HAL_Driver/Inc/Legacy/stm32_hal_legacy.h \
 ../Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_rcc_ex.h \
 ../Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_exti.h \
 ../Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_gpio.h \
 ../Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_gpio_ex.h \
 ../Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_dma.h \
 ../Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_cortex.h \
 ../Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_flash.h \
 ../Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_flash_ex.h \
 ../Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_flash_ramfunc.h \
 ../Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_i2c.h \
 ../Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_i2c_ex.h \
 ../Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_pwr.h \
 ../Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_pwr_ex.h \
 ../Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_uart.h \
 ../Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_uart_ex.h \
 ../NPZ2100/Inc/npz2100_mid.h ../Core/Inc/main.h
../Core/Src/../../NPZ2100/Src/npz2100.c:
../NPZ2100/Inc/npz2100_hal.h:
../Core/Src/../../NPZ2100/Src/npz2100_mid.c:
../NPZ2100/Inc/npz2100_mid.h:
../NPZ2100/Inc/npz2100_hal.h:
../NPZ2100/Inc/npz2100_regs_system.h:
../NPZ2100/Inc/npz2100_regs_io.h:
../NPZ2100/Inc/npz2100_regs_periph.h:
../NPZ2100/Inc/npz2100_regs_adc_log.h:
../Core/Src/../../NPZ2100/Src/npz2100_stm32.c:
../NPZ2100/Inc/npz2100_stm32.h:
../Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal.h:
../Core/Inc/stm32l0xx_hal_conf.h:
../Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_rcc.h:
../Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_def.h:
../Drivers/CMSIS/Device/ST/STM32L0xx/Include/stm32l0xx.h:
../Drivers/CMSIS/Device/ST/STM32L0xx/Include/stm32l053xx.h:
../Drivers/CMSIS/Include/core_cm0plus.h:
../Drivers/CMSIS/Include/cmsis_version.h:
../Drivers/CMSIS/Include/cmsis_compiler.h:
../Drivers/CMSIS/Include/cmsis_gcc.h:
../Drivers/CMSIS/Include/mpu_armv7.h:
../Drivers/CMSIS/Device/ST/STM32L0xx/Include/system_stm32l0xx.h:
../Drivers/STM32L0xx_HAL_Driver/Inc/Legacy/stm32_hal_legacy.h:
../Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_rcc_ex.h:
../Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_exti.h:
../Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_gpio.h:
../Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_gpio_ex.h:
../Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_dma.h:
../Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_cortex.h:
../Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_flash.h:
../Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_flash_ex.h:
../Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_flash_ramfunc.h:
../Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_i2c.h:
../Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_i2c_ex.h:
../Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_pwr.h:
../Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_pwr_ex.h:
../Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_uart.h:
../Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_uart_ex.h:
../NPZ2100/Inc/npz2100_mid.h:
../Core/Inc/main.h:
