/**
 * @file npz2100_stm32.c
 * @brief nPZ2100 STM32 HAL port implementation.
 *
 * This is the ONLY file that includes STM32 HAL headers.
 * npz2100.c and npz2100_mid.c remain strictly platform-agnostic.
 *
 * STM32L053 I²C specifics
 * -----------------------
 * The STM32L053 I²C peripheral uses the STM32CubeL0 HAL:
 *   HAL_I2C_Master_Transmit()  — write N bytes starting at register address
 *   HAL_I2C_Master_Receive()   — read N bytes
 *   HAL_I2C_Mem_Read()         — write register pointer then read (one call)
 *
 * The nPZ2100 HAL write callback receives a buffer where buf[0] is the
 * register address and buf[1..len-1] is data — this maps directly to
 * HAL_I2C_Master_Transmit() with the full buffer in one call.
 *
 * The nPZ2100 HAL read callback uses HAL_I2C_Mem_Read() which internally
 * issues the register-pointer write followed by a restart and data read —
 * exactly the I²C sequence the nPZ2100 expects.
 *
 * I²C address shift
 * -----------------
 * STM32 HAL expects the 7-bit address left-shifted by 1 (i.e. << 1).
 * NPZ2100_I2C_ADDR (0x6F) becomes 0xDE for HAL calls.
 *
 * @version 0.7
 * @date    2026-05-06
 * @author  Nanopower Semiconductor AS
 */

#include "npz2100_stm32.h"
#include <string.h>  /* memset */
#include <main.h>

/* =========================================================================
 * STM32 HAL I²C callbacks
 *
 * These two functions are the only coupling point between the STM32 HAL
 * and the platform-agnostic npz2100 core.  They are stored in the
 * npz2100_hal_t struct and called by npz2100.c / npz2100_mid.c.
 *
 * ctx carries a pointer to the I2C_HandleTypeDef.
 * ======================================================================= */

/**
 * @brief HAL write callback — wraps HAL_I2C_Master_Transmit().
 *
 * buf[0] = register address (prepended by the core driver).
 * buf[1..len-1] = data payload.
 * Issues one START/STOP for the whole buffer — minimal bus transactions.
 */
static npz2100_err_t stm32_i2c_write(uint8_t        i2c_addr,
                                      const uint8_t *buf,
                                      size_t         len,
                                      void          *ctx)
{
    I2C_HandleTypeDef *hi2c = (I2C_HandleTypeDef *)ctx;

    /*
     * STM32 HAL requires the 7-bit address left-shifted by 1.
     * Cast away const for HAL_I2C_Master_Transmit — the HAL prototype
     * takes uint8_t* but does not modify the buffer.
     */
    HAL_StatusTypeDef ret = HAL_I2C_Master_Transmit(
        hi2c,
        (uint16_t)(i2c_addr << 1u),
        (uint8_t *)buf,
        (uint16_t)len,
        NPZ2100_I2C_TIMEOUT_MS);

    return (ret == HAL_OK) ? NPZ2100_OK : NPZ2100_ERR_IO;
}

/**
 * @brief HAL read callback — wraps HAL_I2C_Mem_Read().
 *
 * HAL_I2C_Mem_Read() internally issues:
 *   START, addr+W, reg, rSTART, addr+R, buf[0..len-1], STOP
 * This is exactly the sequence the nPZ2100 expects for register reads.
 */
static npz2100_err_t stm32_i2c_read(uint8_t  i2c_addr,
                                     uint8_t  reg,
                                     uint8_t *buf,
                                     size_t   len,
                                     void    *ctx)
{
    I2C_HandleTypeDef *hi2c = (I2C_HandleTypeDef *)ctx;

    HAL_StatusTypeDef ret = HAL_I2C_Mem_Read(
        hi2c,
        (uint16_t)(i2c_addr << 1u),
        (uint16_t)reg,
        I2C_MEMADD_SIZE_8BIT,
        buf,
        (uint16_t)len,
        NPZ2100_I2C_TIMEOUT_MS);

    return (ret == HAL_OK) ? NPZ2100_OK : NPZ2100_ERR_IO;
}

/* =========================================================================
 * Internal: error code translation
 * ======================================================================= */

/**
 * @brief Convert npz2100_err_t to NPZ2100_Status_t.
 *
 * NPZ2100_Status_t is a typedef alias of npz2100_err_t so this is a
 * direct assignment — kept as a function for readability at call sites.
 */
static inline NPZ2100_Status_t mid_to_status(npz2100_err_t e)
{
    return (NPZ2100_Status_t)e;
}

/* =========================================================================
 * NPZ2100_Init
 * ======================================================================= */

NPZ2100_Status_t NPZ2100_Init(NPZ2100_Handle_t  *hnpz,
                               I2C_HandleTypeDef *hi2c)
{
	int ret = 0;

    if (hnpz == NULL || hi2c == NULL) {
        return NPZ2100_ERR_ARG;
    }

    /* Store I²C handle for use by the callbacks. */
    hnpz->hi2c = hi2c;

    /* Populate platform-agnostic HAL with STM32 I²C callbacks.
     * ctx carries the I²C handle — immutable after init. */
    hnpz->hal.write    = stm32_i2c_write;
    hnpz->hal.read     = stm32_i2c_read;
    hnpz->hal.i2c_addr = NPZ2100_I2C_ADDR;
    hnpz->hal.ctx      = (void *)hi2c;

    /* Seed shadow with power-on reset defaults — no I²C. */
    npz2100_err_t err = npz2100_config_init_defaults(&hnpz->shadow);
    if (err != NPZ2100_OK) {
    	printf("Shadow init failed: %d", ret);
        return mid_to_status(err);
    }

    /* Verify device presence — ID register must equal 0x74. */
    err = npz2100_probe_ll(&hnpz->hal);
    if (err != NPZ2100_OK) {
    	printf("\nPZ2100 not found on I2C @ 0x%02X (err %d)", NPZ2100_I2C_ADDR, ret);
        return mid_to_status(err);
    }

    printf("nPZ2100 ready on I2C @ 0x%02X", NPZ2100_I2C_ADDR);

    return NPZ2100_OK;
}

/* =========================================================================
 * NPZ2100_BootStatus
 * ======================================================================= */

NPZ2100_Status_t NPZ2100_BootStatus(NPZ2100_Handle_t    *hnpz,
                                     NPZ2100_WakeReason_t *reason)
{
    if (hnpz == NULL) {
        return NPZ2100_ERR_ARG;
    }

    uint8_t sta1, sta2, sta3;

    /* Single burst read: STA1 (0x02), STA2 (0x03), STA3 (0x04).
     * Reading STA1 and STA2 resets the nPZ2100 watchdog timer. */
    npz2100_err_t err = npz2100_status_read(&hnpz->hal, &sta1, &sta2, &sta3);
    if (err != NPZ2100_OK) {
        return mid_to_status(err);
    }

    if (reason == NULL) {
        return NPZ2100_OK; /* Caller only needed the watchdog kick. */
    }

    memset(reason, 0, sizeof(*reason));

    /* Decode reset sources. */
    reason->rst_src  = NPZ2100_STA1_RST_SRC_GET(sta1);
    reason->srst_src = NPZ2100_STA1_SRST_SRC_GET(sta1);

    /* ADC and timing flags from STA1. */
    reason->adc1    = (sta1 & NPZ2100_STA1_FADC1_MSK) ? 1u : 0u;
    reason->adc2    = (sta1 & NPZ2100_STA1_FADC2_MSK) ? 1u : 0u;
    reason->adc3    = (sta1 & NPZ2100_STA1_FADC3_MSK) ? 1u : 0u;
    reason->timeout = (sta1 & NPZ2100_STA1_FTOUT_MSK) ? 1u : 0u;

    /* Peripheral trigger bitmask and event flags from STA2. */
    reason->periph_mask = sta2 & 0x3Fu;
    reason->alarm       = (sta2 & NPZ2100_STA2_FALM_MSK) ? 1u : 0u;
    reason->log_full    = (sta2 & NPZ2100_STA2_FLOG_MSK) ? 1u : 0u;

    /* Counter, PA active, NAK mask from STA3. */
    reason->counter   = (sta3 & NPZ2100_STA3_FCNT_MSK) ? 1u : 0u;
    reason->pa_active = (sta3 & NPZ2100_STA3_FPA_MSK)  ? 1u : 0u;
    reason->nak_mask  = sta3 & 0x3Fu;

    return NPZ2100_OK;
}

/* =========================================================================
 * NPZ2100_Readback
 * ======================================================================= */

NPZ2100_Status_t NPZ2100_Readback(NPZ2100_Handle_t *hnpz)
{
    if (hnpz == NULL) {
        return NPZ2100_ERR_ARG;
    }
    return mid_to_status(
        npz2100_map_readback(&hnpz->hal, &hnpz->shadow));
}

/* =========================================================================
 * NPZ2100_ApplyRegmap
 * ======================================================================= */

NPZ2100_Status_t NPZ2100_ApplyRegmap(NPZ2100_Handle_t *hnpz,
                                      const uint8_t    *map,
                                      size_t            map_len)
{
    if (hnpz == NULL || map == NULL || map_len == 0u) {
        return NPZ2100_ERR_ARG;
    }

    /* Validate stream framing before touching the bus. */
    if (npz2100_map_validate(map, map_len) != NPZ2100_OK) {
        return NPZ2100_ERR_ARG;
    }

    return mid_to_status(
        npz2100_map_apply(&hnpz->hal, &hnpz->shadow, map, map_len));
}

/* =========================================================================
 * NPZ2100_GetShadow
 * ======================================================================= */

npz2100_config_t *NPZ2100_GetShadow(NPZ2100_Handle_t *hnpz)
{
    if (hnpz == NULL) {
        return NULL;
    }
    return &hnpz->shadow;
}

/* =========================================================================
 * NPZ2100_ShadowFlush
 * ======================================================================= */

NPZ2100_Status_t NPZ2100_ShadowFlush(NPZ2100_Handle_t *hnpz)
{
    if (hnpz == NULL) {
        return NPZ2100_ERR_ARG;
    }

    npz2100_err_t err = NPZ2100_OK;

    /* Write all non-banked writable registers, diffing against shadow. */
    struct { uint8_t addr; uint8_t *field; } regs[] = {
        { NPZ2100_REG_IOCFG1,    &hnpz->shadow.iocfg1     },
        { NPZ2100_REG_IOCFG2,    &hnpz->shadow.iocfg2     },
        { NPZ2100_REG_IOCFG3,    &hnpz->shadow.iocfg3     },
        { NPZ2100_REG_IOCFG4,    &hnpz->shadow.iocfg4     },
        { NPZ2100_REG_IOCFG5,    &hnpz->shadow.iocfg5     },
        { NPZ2100_REG_SYSCFG1,   &hnpz->shadow.syscfg1    },
        { NPZ2100_REG_SYSCFG2,   &hnpz->shadow.syscfg2    },
        { NPZ2100_REG_TOUT_L,    &hnpz->shadow.tout_l     },
        { NPZ2100_REG_TOUT_H,    &hnpz->shadow.tout_h     },
        { NPZ2100_REG_GCT_MS,    &hnpz->shadow.gct_ms     },
        { NPZ2100_REG_GCT_0,     &hnpz->shadow.gct_0      },
        { NPZ2100_REG_GCT_1,     &hnpz->shadow.gct_1      },
        { NPZ2100_REG_GCT_2,     &hnpz->shadow.gct_2      },
        { NPZ2100_REG_GCT_3,     &hnpz->shadow.gct_3      },
        { NPZ2100_REG_GCT_ALM_0, &hnpz->shadow.gct_alm_0  },
        { NPZ2100_REG_GCT_ALM_1, &hnpz->shadow.gct_alm_1  },
        { NPZ2100_REG_GCT_ALM_2, &hnpz->shadow.gct_alm_2  },
        { NPZ2100_REG_GCT_ALM_3, &hnpz->shadow.gct_alm_3  },
        { NPZ2100_REG_WDOG_L,    &hnpz->shadow.wdog_l     },
        { NPZ2100_REG_WDOG_H,    &hnpz->shadow.wdog_h     },
        { NPZ2100_REG_GTC_CFG,   &hnpz->shadow.gtc_cfg    },
        { NPZ2100_REG_PA_CFG,    &hnpz->shadow.pa_cfg     },
        { NPZ2100_REG_ADCCFG,    &hnpz->shadow.adccfg     },
        { NPZ2100_REG_THROVA1,   &hnpz->shadow.throva1    },
        { NPZ2100_REG_THRUNA1,   &hnpz->shadow.thruna1    },
        { NPZ2100_REG_THROVA2,   &hnpz->shadow.throva2    },
        { NPZ2100_REG_THRUNA2,   &hnpz->shadow.thruna2    },
        { NPZ2100_REG_THROVA3,   &hnpz->shadow.throva3    },
        { NPZ2100_REG_THRUNA3,   &hnpz->shadow.thruna3    },
        { NPZ2100_REG_LOGCFG,    &hnpz->shadow.logcfg     },
        { NPZ2100_REG_LOGSADDR,  &hnpz->shadow.logsaddr   },
        { NPZ2100_REG_CNTCFG,    &hnpz->shadow.cntcfg     },
        { NPZ2100_REG_CNT_TRIG_0,&hnpz->shadow.cnt_trig_0 },
        { NPZ2100_REG_CNT_TRIG_1,&hnpz->shadow.cnt_trig_1 },
        { NPZ2100_REG_CNT_TRIG_2,&hnpz->shadow.cnt_trig_2 },
        { NPZ2100_REG_CNT_TRIG_3,&hnpz->shadow.cnt_trig_3 },
        { NPZ2100_REG_SRAM_BANK, &hnpz->shadow.sram_bank  },
    };

    for (size_t i = 0u; i < sizeof(regs)/sizeof(regs[0]) && err == NPZ2100_OK; i++) {
        err = npz2100_shadow_write_reg(&hnpz->hal, &hnpz->shadow,
                                        regs[i].addr, *regs[i].field);
    }

    /* Write all 6 peripheral banks. */
    for (uint8_t slot = 0u;
         slot <= NPZ2100_P_BANK_MAX && err == NPZ2100_OK;
         slot++) {
        err = npz2100_periph_apply(&hnpz->hal, &hnpz->shadow, slot);
    }

    return mid_to_status(err);
}

/* =========================================================================
 * SRAM access
 * ======================================================================= */

NPZ2100_Status_t NPZ2100_SramWrite(NPZ2100_Handle_t *hnpz,
                                    uint8_t           sram_addr,
                                    const uint8_t    *data,
                                    size_t            len)
{
    if (hnpz == NULL) {
        return NPZ2100_ERR_ARG;
    }
    return mid_to_status(
        npz2100_sram_write_ll(&hnpz->hal, &hnpz->shadow,
                               sram_addr, data, len));
}

NPZ2100_Status_t NPZ2100_SramRead(NPZ2100_Handle_t *hnpz,
                                   uint8_t           sram_addr,
                                   uint8_t          *data,
                                   size_t            len)
{
    if (hnpz == NULL) {
        return NPZ2100_ERR_ARG;
    }
    return mid_to_status(
        npz2100_sram_read_ll(&hnpz->hal, &hnpz->shadow,
                              sram_addr, data, len));
}

NPZ2100_Status_t NPZ2100_PeriphReadValue(NPZ2100_Handle_t *hnpz,
                                          uint8_t           slot,
                                          uint16_t         *value)
{
    if (hnpz == NULL || value == NULL || slot > NPZ2100_P_BANK_MAX) {
        return NPZ2100_ERR_ARG;
    }
    return mid_to_status(
        npz2100_periph_read_value_ll(&hnpz->hal, &hnpz->shadow,
                                     slot, value));
}

/* =========================================================================
 * Control
 * ======================================================================= */

NPZ2100_Status_t NPZ2100_EnterIdle(NPZ2100_Handle_t *hnpz)
{
    if (hnpz == NULL) {
        return NPZ2100_ERR_ARG;
    }
    /*
     * After this write the nPZ2100 will de-assert SW_HP and cut power
     * to the STM32.  Execution does not continue past this point in
     * normal operation.
     */
    return mid_to_status(npz2100_enter_idle_ll(&hnpz->hal));
}

NPZ2100_Status_t NPZ2100_SoftReset(NPZ2100_Handle_t *hnpz)
{
    if (hnpz == NULL) {
        return NPZ2100_ERR_ARG;
    }
    return mid_to_status(npz2100_soft_reset_ll(&hnpz->hal));
}
